def build_dataset(args):
    if args.dataset_file == 'SHHAFv2':
        from crowd_datasets.SHHAFv2.loading_data import loading_data
        return loading_data
    if args.dataset_file == 'SHHAFv2-R':
        from crowd_datasets.SHHAFv2.loading_data2 import loading_data
        return loading_data
    if args.dataset_file == 'SHHAFv2-B':
        from crowd_datasets.SHHAFv2.loading_data3 import loading_data
        return loading_data
    if args.dataset_file == 'SHHAFv2-B-R':
        from crowd_datasets.SHHAFv2.loading_data4 import loading_data
        return loading_data
    if args.dataset_file == 'SHHAR':
        from crowd_datasets.SHHAR.loading_data import loading_data
        return loading_data
    if args.dataset_file == 'SHHAR2':
        from crowd_datasets.SHHAR.loading_data2 import loading_data
        return loading_data
    if args.dataset_file == 'ShanghaiTechRGBD':
        from crowd_datasets.ShanghaiTechRGBD.loading_data import loading_data
        return loading_data
    if args.dataset_file == 'Hazy-ShanghaiTechRGBD':
        from crowd_datasets.Hazy_ShanghaiTechRGBD.loading_data import loading_data
        return loading_data
    if args.dataset_file == 'Hazy-ShanghaiTechRGBD-R':
        from crowd_datasets.Hazy_ShanghaiTechRGBD.loading_data2 import loading_data
        return loading_data
    if args.dataset_file == 'Rainy-ShanghaiTechRGBD':
        from crowd_datasets.Rainy_ShanghaiTechRGBD.loading_data import loading_data
        return loading_data
    if args.dataset_file == 'Rainy-ShanghaiTechRGBD-R':
        from crowd_datasets.Rainy_ShanghaiTechRGBD.loading_data2 import loading_data
        return loading_data
    if args.dataset_file == 'Hazy-JHU':
        from crowd_datasets.Hazy_JHU.loading_data import loading_data
        return loading_data
    if args.dataset_file == 'Hazy-JHU-R':
        from crowd_datasets.Hazy_JHU.loading_data2 import loading_data
        return loading_data
    if args.dataset_file == 'Rainy-JHU':
        from crowd_datasets.Rainy_JHU.loading_data import loading_data
        return loading_data
    if args.dataset_file == 'Rainy-JHU-R':
        from crowd_datasets.Rainy_JHU.loading_data2 import loading_data
        return loading_data
    if args.dataset_file == 'Snowy-JHU':
        from crowd_datasets.Snowy_JHU.loading_data import loading_data
        return loading_data
    if args.dataset_file == 'Snowy-JHU-R':
        from crowd_datasets.Snowy_JHU.loading_data2 import loading_data
        return loading_data
    if args.dataset_file == 'Dark':
        from crowd_datasets.Dark_RGBT_CC.loading_data import loading_data
        return loading_data
    if args.dataset_file == 'Dark-R':
        from crowd_datasets.Dark_RGBT_CC.loading_data2 import loading_data
        return loading_data
    if args.dataset_file == 'Hazy-SHTA-R':
        from crowd_datasets.Hazy_ShanghaiTech.loading_data_A import loading_data
        return loading_data
    if args.dataset_file == 'Hazy-SHTB-R':
        from crowd_datasets.Hazy_ShanghaiTech.loading_data_B import loading_data
        return loading_data
    if args.dataset_file == 'Hazy-SHTA':
        from crowd_datasets.Hazy_ShanghaiTech.loading_data2_A import loading_data
        return loading_data
    if args.dataset_file == 'Hazy-SHTB':
        from crowd_datasets.Hazy_ShanghaiTech.loading_data2_B import loading_data
        return loading_data
    return None
